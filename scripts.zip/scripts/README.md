## Submodules
- [Mapping Process](./mapping_files/README.md)
- [Validation Workflow](./tools_validation/README.md)
- [FM generation](../fm-json-kubernetes/README.md)